/*
 * sum.c
 *
 *  Created on: 8 août 2020
 *      Author: Daniel Mårtensson
 */

#include "../../Headers/Functions.h"

/*
 * A[m*n]
 * l = 1 sum on rows -> First row is the result
 * l = 2 sum on columns -> First column is the result
 */
void sum(float A[], uint32_t row, uint32_t column, uint8_t l) {
	if (l == 1) {
		for (uint32_t i = 1; i < row; i++) {
			for (uint32_t j = 0; j < column; j++) {
				A[j] += A[i * column + j];
			}
		}
	} else if (l == 2) {
		for (uint32_t i = 0; i < row; i++) {
			for (uint32_t j = 1; j < column; j++) {
				A[i * column] += A[i * column + j];
			}
		}
	}
}

