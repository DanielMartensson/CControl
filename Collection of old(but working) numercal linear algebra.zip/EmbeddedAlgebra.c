/*
 ============================================================================
 Name        : EmbeddedAlgebra.c
 Author      : 
 Version     : 1.3
 Copyright   : MIT
 Description : Examples how to use
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include "LinearAlgebra/declareFunctions.h"
#include <time.h>

int main() {


	clock_t start, end;
	float cpu_time_used;

	start = clock();

	/*
	 * Create a matrix
	 */
	float values1[5][5] = { { 1, 76, 86, 1, 5 },
				{ 1, 5, -6, 0, 3 },
				{ -5, 7, 3, 87, 3 },
				{ -8, 3, 1, 4, -1 },
				{ 7, 9, 1, 28, 4 } };

	printf("Create matrix\n");
	matrix* A = create(*values1, 5, 5);
	printMatrix(A);
	/*
	 * Create a vector
	 */
	float values2[5][1] = { { 2.3 }, { 4.4 }, { 3.1 }, { -3.2 }, { 3.13 } };
	printf("Create vector\n");
	matrix* b = create(*values2, 5, 1);

	/*
	 * Create one long vector from 1D array
	 */
	printf("Create one long vector from 1D array\n");
    float vector[72] = { 0.00000,   1.89649,   3.30777,   3.40331,   3.23615,   3.18151,   3.19049,   3.20013,   3.20132,   3.20031,   3.19990,


			   3.19993,   3.20000,   3.20001,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,


			   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,


			   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,


			   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,


			   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,


			   3.20000,   3.20000,   3.20000,   3.20000,   3.20000,   3.20000};


	// Create two vectors
	matrix* U = create(vector, 72, 1); // Notice that we don't send the first argument with *vector, only vector. Compare that with 2D array values1
	printMatrix(U);
	freeMatrix(U);

	/*
	 * Take the absolute value of a matrix/vector
	 */
	printf("Take absolute value for matrix or vector\n");
	matrix* absMatrix = absm(A);
	printMatrix(absMatrix);
	freeMatrix(absMatrix);

	/*
	 * Add matrix A with matrix A
	 */
	printf("Add matrix A with A\n");
	matrix* addMatrix = add(A, A);
	printMatrix(addMatrix);
	freeMatrix(addMatrix);

	/*
	 * Add matrix A with vector b
	 */
	printf("Add matrix A with vector b\n");
	addMatrix = add(A, b);
	printMatrix(addMatrix);
	freeMatrix(addMatrix);

	/*
	 * Do cholsky factorization
	 */
	float values3[3][3] = { { 1, -1, -1 }, { -1, 2, 0 }, { -1, 0, 3 } };
	printf("Do cholsky factorization\n");
	matrix* C = create(*values3, 3, 3);
	matrix* L = chol(C);
	printMatrix(L);
	freeMatrix(L);


	/*
	 * Create the cofactor matrix
	 */
	printf("Create cofactor matrix\n");
	matrix* co = cofact(C);
	printMatrix(co);
	freeMatrix(co);
	freeMatrix(C);

	/*
	 * Copy a matrix values to another matrix
	 */
	printf("Copy a matrix\n");
	matrix* copyMat = initMatrix(5, 5);
	copyval(A, copyMat); // Give copyMat the same values as matrix A
	printMatrix(copyMat);
	freeMatrix(copyMat);

	/*
	 * Cut a matrix
	 */
	printf("Cut a matrix\n");
	matrix* cutMat = cut(A, 0, 2, 0, 2); // This will be equal as MATLAB A(1:3, 1:3) because command cut have indexing from zero
	printMatrix(cutMat);
	freeMatrix(cutMat);

	/*
	 * Find the determinant
	 */
	printf("Find determinant of matrix A\n");
	float d = det(A);
	printf("Determinant is = %f\n\n", d);

	/*
	 * Create a diagonal matrix
	 */
	printf("Create diagonal matrix\n");
	float vectorDiagonal[6] = { 1, 2, 3, 7, 5, 4 };
	matrix* diagMat = diag(vectorDiagonal, 6);
	printMatrix(diagMat);
	freeMatrix(diagMat);

	/*
	 * Create a vector of a matrix, where the vector has the diagonal values of the matrix
	 */
	printf("Create vector from the diagonals of a matrix\n");
	matrix* diagMat2 = diagm(A); // This is the same as MATLAB command diag. So there is a difference between diag and diagm.
	printMatrix(diagMat2);
	freeMatrix(diagMat2);

	/*
	 * Create the dot product of matrix b and matrix b
	 */
	printf("Compute dot product\n");
	float dotMat = dot(b, b);
	printf("Dot product is = %f\n\n", dotMat);

	/*
	 * Create a identity matrix of nxn size
	 */
	printf("Create identity matrix\n");
	matrix* I = eye(6, 6);
	printMatrix(I);
	freeMatrix(I);

	/*
	 * Create a hankel matrix of the vector vectroDiagonal
	 */
	printf("Create hankel matrix\n");
	matrix* hankMat = hankel(vectorDiagonal, 6, 0); // vector, length of vector, 0 shift step
	printMatrix(hankMat);
	freeMatrix(hankMat);

	/*
	 * Extend horizontal matrix. Concat A and b
	 */
	printf("Concat matrix on the horizon\n");
	matrix* horzMat = horzcat(A, b);
	printMatrix(horzMat);
	freeMatrix(horzMat);

	/*
	 * Create a inverse of matrix A. This uses LU-factorization
	 */
	printf("Create inverse matrix of A\n");
	matrix* invMat = inv(A);
	printMatrix(invMat);
	freeMatrix(invMat);

	/*
	 * Do LU-factorization
	 */
	printf("Do LU-factorization\n");
	matrix* l = initMatrix(5, 5);
	matrix* u = initMatrix(5, 5);
	lu(A, l, u);
	printMatrix(l);
	printMatrix(u);
	freeMatrix(l);
	freeMatrix(u);

	/*
	 * Find maximum value of the vector b
	 */
	printf("Find maximum value of vector b\n");
	int index;
	float value;
	max(b, &value, &index);
	printf("The maximum value of b was %f and the index where %d\n\n", value, index);

	/*
	 * Find minimum value of the vector b
	 */
	printf("Find minimum value of vector b\n");
	min(b, &value, &index);
	printf("The minimum value of b was %f and the index where %d\n\n", value,
			index);

	/*
	 * Multiply matrix A with vector b
	 */
	printf("Multiply matrix A with vector b\n");
	matrix* mulMat = mul(A, b, false); // false = not elementwise e.g A*b. true = element wise e.g A.*b
	printMatrix(mulMat);
	freeMatrix(mulMat);

	/*
	 * Multiply matrix A with vector b with element wise
	 */
	printf("Multiply matrix A with vector b as element wise\n");
	mulMat = mul(A, b, true); // false = not elementwise e.g A*b. true = element wise e.g A.*b
	printMatrix(mulMat);
	freeMatrix(mulMat);

	/*
	 * Multiply matrix A with matrix A with element wise
	 */
	printf("Multiply matrix A with matrix A as element wise\n");
	mulMat = mul(A, A, true); // false = not elementwise e.g A*b. true = element wise e.g A.*b
	printMatrix(mulMat);
	freeMatrix(mulMat);

	/*
	 * Do the euclidean norm on a vector
	 */
	printf("Do the euclidean norm on a vector\n");
	float normValue = norm(b);
	printf("The norm is %f\n\n", normValue);

	/*
	 * Create ones-matrix
	 */
	printf("Create ones-matrix\n");
	matrix* oneMat = ones(6, 5);
	printMatrix(oneMat);
	freeMatrix(oneMat);

	/*
	 * Create pseudo inverse of matrix A
	 */
	printf("Create pseudo inverse of matrix A\n");
	matrix* pMat = pinv(A);
	printMatrix(pMat);
	freeMatrix(pMat);

	/*
	 * Do QR-factorization
	 */
	printf("Do QR-factorization\n");
	matrix* q = initMatrix(5, 5);
	matrix* r = initMatrix(5, 5);
	qr(A, q, r);
	printMatrix(q);
	printMatrix(r);
	freeMatrix(r);
	freeMatrix(q);

	/*
	 * Repeat matrix A, 3 times to left and one times down
	 */
	printf("Repeat matrix A, 3 times to left and one times down\n");
	matrix* repMatrix = repmat(A, 2, 1); // Remember! Indexing from zero
	printMatrix(repMatrix);
	freeMatrix(repMatrix);

	/*
	 * Scale a matrix or vector with a number. You can use this if you want to copy a matrix or vector. Just multiply with 1
	 */
	printf("Scale a vector with 4.1\n");
	matrix* scMat = scale(b, 4.1);
	printMatrix(scMat);
	// We not going to delete this matrix yet!

	/*
	 * Get the size. This can be used when you don't want to read the size every time from the struct
	 */
	printf("Find the dimensions of matrix A\n");
	int n;
	int m;
	size(A, &n, &m);
	printf("The size of matrix A is n = %d and m = %d\n\n", n, m);

	/*
	 * Do element square root on every element. Notice that the values cannot be netative, else you get 'nan' values e.g complex
	 */
	printf("Do sqrt on all elements of a matrix\n");
	matrix* sqrM = sqrtm(A); // This is equal to MATLAB's sqrt(A) and not sqrtm(A) in MATLAB!!! sqrt is used by C-standard library
	printMatrix(sqrM);
	freeMatrix(sqrM);

	/*
	 * Substract A minus matrix A scaled 0.3
	 */
	printf("Use subtraction with a matrix A minus A*0.3\n");
	matrix* D = scale(A, 0.3);
	matrix* subMat = sub(A, D);
	printMatrix(subMat);
	freeMatrix(subMat);
	freeMatrix(scMat); // Now we are deleting it
	freeMatrix(D);

	/*
	 * Substract A minus vector b
	 */
	printf("Substract A minus vector b\n");
	subMat = sub(A, b);
	printMatrix(subMat);
	freeMatrix(subMat);

	/*
	 * Summarize a matrix. This is equal to sum in MATLAB
	 */
	printf("Summarize a matrix A\n");
	matrix* summMat = summ(A);
	printMatrix(summMat);
	freeMatrix(summMat);

	/*
	 * Do Singular Value Decomposition
	 */
	printf("Do Singular Value Decomposition on A\n");
	matrix* u1 = initMatrix(5, 5);
	matrix* s1 = initMatrix(5, 5);
	matrix* v1 = initMatrix(5, 5);
	svd(A, u1, s1, v1);
	printMatrix(u1);
	printMatrix(s1);
	printMatrix(v1);
	freeMatrix(u1);
	freeMatrix(s1);
	freeMatrix(v1);

	/*
	 * Create a Toeplitz matrix of a vector - 1D array
	 */
	printf("Create a Toeplitz matrix of a vector\n");
	float toeValues[8] = { 2, 5, 1, 6, 7, 3, 1, 4 };
	matrix* toeMat = toeplitz(toeValues, 8); // Length 8
	printMatrix(toeMat);
	freeMatrix(toeMat);

	/*
	 * Do the transpose of matrix A
	 */
	printf("Do transpose of matrix A\n");
	matrix* tMat = tran(A);
	printMatrix(tMat);
	freeMatrix(tMat);

	/*
	 * Turn A into a lower triangular matrix
	 */
	printf("Create lower triangular matrix of matrix A\n");
	matrix* tl = tril(A, 0); // No shift
	printMatrix(tl);
	freeMatrix(tl);

	/*
	 * Turn A into a upper triangular matrix
	 */
	printf("Create upper triangular matrix of matrix A\n");
	matrix* tu = triu(A, 1); // 1 shift
	printMatrix(tu);
	freeMatrix(tu);

	/*
	 * Turn matrix A into a long vector. This is the same as MATLAB command as A(:) or Octave command vec(A)
	 */
	printf("Turn matrix into a long vector\n");
	matrix* vMat = vec(A);
	printMatrix(vMat);
	freeMatrix(vMat);

	/*
	 * Do vertical matrix A and transpose of vector b
	 */
	printf("Do vertical matrix A and transpose of vector b\n");
	matrix* transVector = tran(b); // One row matrix from one column matrix
	matrix* vertMat = vertcat(A, transVector);
	printMatrix(vertMat);
	printMatrix(transVector);
	freeMatrix(transVector);
	freeMatrix(vertMat);

	/*
	 * Create zeros matrix
	 */
	printf("Create zeros matrix\n");
	matrix* z = zeros(6,3);
	printMatrix(z);
	freeMatrix(z);

	/*
	 * Reset matrix A
	 */
	printf("Reset matrix A to zeros\n");
	resetMatrix(A);
	printMatrix(A);
	freeMatrix(A);

	/*
	 * Delete vector b
	 */
	freeMatrix(b);

	/*
	 * Check the total time
	 */
	end = clock();
	cpu_time_used = ((float) (end - start)) / CLOCKS_PER_SEC;
	printf("Total speed  was %f,", cpu_time_used);

	return EXIT_SUCCESS;

}
