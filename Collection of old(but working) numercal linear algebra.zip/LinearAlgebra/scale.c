/*
 * scale.c
 *
 *  Created on: 13 jan. 2019
 *      Author:
 */

#include "declareFunctions.h"

/*===========================================================================
 * scale
 * Multiply a matrix or vector with a scalar float value
 * Input: Matrix, scalar value of float type
 * Return: Matrix
 * Works: OK
 *=========================================================================*/
matrix* scale(matrix* a, float value) {
	int elements = a->column * a->row;
	matrix* out = initMatrix(a->row, a->column);
	float* ptrM = a->data;
	float* ptrOut = out->data;

	for (int i = 0; i < elements; i++) {
		*(ptrOut++) = *(ptrM++) * value;
	}

	return out;
}
