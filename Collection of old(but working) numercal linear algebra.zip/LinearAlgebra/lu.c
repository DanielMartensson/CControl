/*
 * lu.c
 *
 *  Created on: 17 jan. 2019
 *      Author: 
 */

#include "declareFunctions.h"

/*===========================================================================
 * lu
 * Solve the LU factorization by using the Crout method
 * Input: Matrix
 * Return: Matrix
 * Works: OK
 *=========================================================================*/
void lu(matrix* a, matrix* l, matrix* u) {
	// Get info about matrix 'a'
	int n = a->row;
	int m = a->column;
	float* ptr_a = a->data;

	// Get pointers
	float* ptr_l = l->data;
	float* ptr_u = u->data;

	float sum = 0;

	// Initial values for matrix u
	memset(ptr_u, 1, m * n * sizeof(float));


	for (int j = 0; j < n; j++) {
		for (int i = j; i < n; i++) {
			sum = 0;
			for (int k = 0; k < j; k++) {
				sum = sum + *((ptr_l + i*n) + k) * (*((ptr_u + k*n) + j));
			}
			*((ptr_l + i*n) + j) = *((ptr_a + i*n) + j) - sum;
		}

		for (int i = j; i < n; i++) {
			sum = 0;
			for (int k = 0; k < j; k++) {
				sum = sum + *((ptr_l + j*n) + k) * (*((ptr_u + k*n) + i));
			}
			if (*((ptr_l + j*n) + j) == 0) {
				printf("det(L) close to 0!\n Can't divide by 0...\n");
				*((ptr_l + j*n) + j) = pow(2.2204, -16); // Same as eps command in MATLAB
			}
			*((ptr_u + j*n) + i) = (*((ptr_a + j*n) + i) - sum) / (*((ptr_l + j*n) + j));
		}
	}
}
