/*
 * ones.c
 *
 *  Created on: 13 jan. 2019
 *      Author: 
 */

#include "declareFunctions.h"

/*===========================================================================
 * ones
 * Returns an ones matrix of size n by m
 * Input: int row, int column
 * Return: Matrix
 * Works: OK
 *=========================================================================*/
matrix* ones(int n, int m) {

	matrix* out = initMatrix(n, m);

	float* ptr = out->data;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			*(ptr++) = 1.0;
		}
	}

	return out;
}
