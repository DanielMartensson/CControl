/*
 * qr.c
 *
 *  Created on: 13 jan. 2019
 *      Author: 
 */

#include "declareFunctions.h"


/*===========================================================================
 * qr
 * Get Q and R matrix from matrix by using Modified Gram-Schmidt method
 * Input: Matrix
 * Return: void
 * Works: OK
 *=========================================================================*/
void qr(matrix* a, matrix* q, matrix* r) {

	// Get info about matrix a
	int n = a->row;
	int m = a->column;
	float* ptr = a->data;

	// Get data
	float* ptr_q = q->data;
	float* ptr_r = r->data;

	matrix* c1;
	matrix* c2;


	for(int k = 0; k < m; k++){
		// Insert vector
		for(int j = 0; j < n; j++)
			*((ptr_q + j*n) + k) = *((ptr + j*n) + k);

		// Do the dot product
		for(int i = 0; i < k; i++){
			c1 = cut(q, 0, n-1, i, i);
			c2 = cut(q, 0, n-1, k,k);
			*((ptr_r + i*n)+k) = dot(c1, c2);
			freeMatrix(c1);
			freeMatrix(c2);

			// Insert vector again
			for(int j = 0; j < n; j++)
				*((ptr_q + j*n) + k) = *((ptr_q + j*n) + k) - *((ptr_r + i*n)+k)*(*((ptr_q + j*n) +i));

		}

		c1 = cut(q, 0, n-1, k, k);
		*((ptr_r+k*n)+k) = -norm(c1); // Important with negative
		freeMatrix(c1);
		// Insert vector again
		for(int j = 0; j < n; j++){
			if(*((ptr_r + k*n) + k) ==  0){
				*((ptr_r + k*n) + k) = pow(2.2204, -16); // Same as eps command in MATLAB
			}
			*((ptr_q + j*n) + k) = (*((ptr_q + j*n) + k)) / (*((ptr_r + k*n) + k));
		}

	}

}

/* MATLAB CODE
 * function [Q,R] =  mgs(X)
    % Modified Gram-Schmidt.  [Q,R] = mgs(X);
    % G. W. Stewart, "Matrix Algorithms, Volume 1", SIAM, 1998.
    [n,p] = size(X);
    Q = zeros(n,p);
    R = zeros(p,p);
    for k = 1:p
        Q(:,k) = X(:,k);
        for i = 1:k-1
            R(i,k) = Q(:,i)'*Q(:,k);
            Q(:,i)'*Q(:,k)
            Q(:,k) = Q(:,k) - R(i,k)*Q(:,i);
        end
        R(k,k) = -norm(Q(:,k))';
        Q(:,k) = Q(:,k)/R(k,k);
    end
end
 */

