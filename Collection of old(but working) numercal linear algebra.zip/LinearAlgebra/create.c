/*
 * create.c
 *
 *  Created on: 13 jan. 2019
 *      Author: 
 */

#include "declareFunctions.h"

/*===========================================================================
 * create
 * Create a matrix or vector with a 2D array
 * Input: 2D float array pointer, int row, int column
 * Return: matrix or vector
 * Works: OK
 *=========================================================================*/
matrix* create(float* arr2D, int n, int m) {

	// Init a matrix
	matrix* out = initMatrix(n, m);
	float* ptr = out->data;

	// Insert all values
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			*(ptr++) = *((arr2D + i * m) + j);
		}
	}
	// Return
	return out;

}
