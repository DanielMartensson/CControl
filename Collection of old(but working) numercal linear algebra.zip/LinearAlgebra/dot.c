/*
 * dot.c
 *
 *  Created on: 13 jan. 2019
 *      Author:
 */

#include "declareFunctions.h"

/*===========================================================================
 * dot
 * Get dot product of two one-column matricies
 * Input: Vector (1 column matrix), Vector (1 column matrix)
 * Return: dot product
 * Works: OK
 *=========================================================================*/
float dot(matrix* a, matrix* b) {

	// Find the data and row length
	int n = a->row;
	float* data_a = a->data;
	float* data_b = b->data;

	// Reset
	float sum = 0;

	// Multiply each row
	for (int i = 0; i < n; ++i) {
		sum += (*(data_a + i)) * (*(data_b + i));
	}
	return sum;

}
