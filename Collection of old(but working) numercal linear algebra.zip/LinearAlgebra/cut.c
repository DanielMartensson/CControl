/*
 * cut.c
 *
 *  Created on: 13 jan. 2019
 *      Author: 
 */

#include "declareFunctions.h"

/*===========================================================================
 * cut
 * Cut out a matrix or vector
 * Input: Matrix, int start at row, int stop at row, int start at column, int stop at column
 * If you want to cut a 3x3 matrix of a 5x5 matix, you need to say cut(mat, 0, 4, 0, 4) because indexing is from zero
 * Works: OK
 *=========================================================================*/
matrix* cut(matrix* a, int start_n, int stop_n, int start_m, int stop_m) {

	int in_columns = a->column;
        float* data = a->data + start_n * in_columns + start_m;

        // Create the output
        matrix* out = initMatrix(stop_n - start_n + 1, stop_m - start_m + 1);
        float* ptr = out->data;
        int out_columns = out->column;

        // Instead of having two for loops, we just copy the whole row at once.
        for (int i = start_n; i < stop_n + 1; i++) {
        	memcpy(ptr, data, sizeof(float) * out_columns);
      		ptr += out_columns;
      		data += in_columns;
   	}

	return out;
}
