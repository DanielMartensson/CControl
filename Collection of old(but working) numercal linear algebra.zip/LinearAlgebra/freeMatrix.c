/*
 * freeMatrix.c
 *
 *  Created on: 13 jan. 2019
 *      Author:
 */

#include "declareFunctions.h"

/*===========================================================================
 * freeMatrix
 * Frees the resources of a matrix
 * Input: Matrix
 * Return: void
 * Works: OK
 *=========================================================================*/
void freeMatrix(matrix* a) {
	if (a != NULL) {
		if (a->data != NULL) {
			free(a->data);
			a->data = NULL;
		}

		free(a);
		a = NULL;
	}
}
