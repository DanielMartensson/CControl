/*
 * det.c
 *
 *  Created on: 13 jan. 2019
 *      Author:
 */

#include "declareFunctions.h"

/*===========================================================================
 * det
 * Find the determinant of a square matrix
 * Input: Matrix
 * Return: Determinant
 * Works: OK
 *=========================================================================*/
float det(matrix *a) {

	// Get dimensions of a
	int n = a->row;
	float* ptr = a->data;

	if (n == 1) {
		// 1x1 "matrix" - Just return the value
		return *(a->data);
	} else if (n == 2) {
		// 2x2 matrix - Easy
		return *(ptr + 0) * *(ptr + 3) - *(ptr + 1) * *(ptr + 2);
	} else if (n == 3) {

		// Don't change this! It works fine for 3x3 - Took me long time to write this
		return (*(ptr + 0)) * (*(ptr + 4)) * (*(ptr + 8))
				+ (*(ptr + 1)) * (*(ptr + 5)) * (*(ptr + 6))
				+ (*(ptr + 2)) * (*(ptr + 3)) * (*(ptr + 7)) -

		(*(ptr + 6)) * (*(ptr + 4)) * (*(ptr + 2))
				- (*(ptr + 7)) * (*(ptr + 5)) * (*(ptr + 0))
				- (*(ptr + 8)) * (*(ptr + 3)) * (*(ptr + 1));

	} else {

		float mat[n][n];
		float ratio;
		float determinant = 1; // Initial det value

		// We need to create the matrix into an array matrix, like a normal matrix again
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				mat[i][j] = *((ptr + i * n) + j);
			}
		}

		// Gauss Elimination Easy and fast algorithm to find the determinant of a nxn matrix
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (j > i) {
					// We cannot divide with zero
					if (mat[i][i] == 0){
						mat[i][i] = pow(2.2204, -16); // Same as MATLAB command eps
					}
					ratio = mat[j][i] / mat[i][i];
					for (int k = 0; k < n; k++) {
						mat[j][k] -= ratio * mat[i][k];
					}
				}
			}
		}

		// Find det
		for (int i = 0; i < n; i++) {
			determinant *= mat[i][i];
		}

		return determinant;
	}

}
