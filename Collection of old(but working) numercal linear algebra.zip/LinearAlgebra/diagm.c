/*
 * diagm.c
 *
 *  Created on: 15 jan. 2019
 *      Author:
 */

#include "declareFunctions.h"

/*===========================================================================
 * diagm
 * Returns an vector matrix of an matrix
 * Input: Matrix
 * Return: Matrix
 * Works: OK
 *=========================================================================*/
matrix* diagm(matrix* a){
	// Get info
	int n = a->row;
	int m = a->column;
	float* ptr_a = a->data;

	// Create vector
	matrix* out = initMatrix(n, 1);
	float* ptr_out = out->data;

	// This will take the diagonal of matrix a and turn it to a vector matrix
	for(int i = 0; i < n; i++){
		for(int j = 0; j < m; j++){
			if(i == j)
				*(ptr_out++) =  *((ptr_a + i*n) + j);
		}
	}

	return out;
}
