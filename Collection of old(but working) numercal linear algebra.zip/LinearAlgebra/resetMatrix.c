/*
 * resetMatrix.c
 *
 *  Created on: 22 jan. 2019
 *      Author: 
 */


#include "declareFunctions.h"

/*===========================================================================
 * resetMatrix
 * Turn all elements to zero
 * Input: Matrix
 * Return: void
 * Works: OK
 *=========================================================================*/
void resetMatrix(matrix* a){
	memset(a->data, 0, a->column * a->row * sizeof(float));
}
