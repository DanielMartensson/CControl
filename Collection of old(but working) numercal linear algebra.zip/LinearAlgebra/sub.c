/*
 * sub.c
 *
 *  Created on: 13 jan. 2019
 *      Author:
 */

#include "declareFunctions.h"

/*===========================================================================
 * sub
 * Substract a matrix with another matrix
 * Input: Matrix, Matrix
 * Retrun: Matrix
 * Works: OK
 *=========================================================================*/
matrix* sub(matrix* a, matrix* b) {
	// Get the dimensions - they both are the same
	int row = a->row;
	int column = a->column;
	int column_b = b->column;

	// Data
	float* data_a = a->data;
	float* data_b = b->data;

	matrix* out = initMatrix(row, column);
	float* ptr = out->data;

	// Substract all values
	if (column_b > 1) { // If we do matrix - matrix
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < column; j++) {
				*(ptr++) = *(data_a++) - *(data_b++);
			}
		}
	} else { // if we do matrix - vector
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < column; j++) {
				*(ptr++) = *(data_a++) - *(data_b + i);
			}
		}
	}
	return out;

}
