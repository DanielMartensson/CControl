/*
 * summ.c
 *
 *  Created on: 20 jan. 2019
 *      Author:
 */

#include "declareFunctions.h"

/*===========================================================================
 * sum
 * Sum all the columns into one row matrix
 * Input: Matrix (vector)
 * Return: Matrix
 * Works: OK
 *=========================================================================*/
matrix* summ(matrix* a) {
	int n = a->row;
	int m = a->column;
	float* ptr = a->data;

	matrix* out = initMatrix(1, m);
	float* ptr_out = out->data;

	for(int j = 0; j < m; j++){
		for(int i = 0; i < n; i++){
			*(ptr_out + j) += *((ptr + i*m) + j);
		}
	}

	return out;
}
