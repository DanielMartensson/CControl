/*
 * copyval.c
 *
 *  Created on: 15 jan. 2019
 *      Author: 
 */

#include "declareFunctions.h"

/*===========================================================================
 * copyval
 * Copy all values from matrix a to matrix b
 * Input: Matrix, matrix
 * Return: void
 * Works: OK
 *=========================================================================*/
void copyval(matrix*a, matrix* b){
	memcpy(b->data, a->data, b->column * b->row * sizeof(float));
}
