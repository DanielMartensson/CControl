/*
 * diag.c
 *
 *  Created on: 13 jan. 2019
 *      Author: 
 */

#include "declareFunctions.h"

/*===========================================================================
 * diag
 * Returns an diag matrix of an 1D array
 * Input: 1D array (normal in other words), int length
 * Return: Matrix
 * Works: OK
 *=========================================================================*/
matrix* diag(float* arr, int length) {

	/*
	 * The reason why float* arr is not a matrix argument is because when we create a matrix from
	 * the beginning, we use float arrays. It makes no sense to first create a single column matrix
	 * and then turn it to a diagonal. You will have to write more code then.
	 */

	matrix* out = initMatrix(length, length);

	float* ptr = out->data;
	for (int i = 0; i < length; i++) {
		*ptr = arr[i];
		ptr += length + 1;
	}

	return out;
}
