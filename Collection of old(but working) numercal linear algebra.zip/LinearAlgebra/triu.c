/*
 * triu.c
 *
 *  Created on: 15 jan. 2019
 *      Author:
 */

#include "declareFunctions.h"

/*===========================================================================
 * triu
 * Find the upper triangular matrix of matrix 'a'
 * Input: matrix* a, int shift
 * Return: Matrix
 * Works: OK
 *=========================================================================*/
matrix* triu(matrix* a, int shift){

	// Get info about matrix a
	int n = a->row;
	int m = a->column;
	float* ptr_a = a->data;

	matrix* out = initMatrix(n, m);
	float* ptr_out = out->data;

	// Create a triangular matrix
	for(int i = 0; i < n; i++){
		for(int j = 0; j < m; j++){
			// Do the "jump"
			if(j == 0){
				j = i + shift; // When we are at column 0 again, jump then n rows + shift at the right
			}
			// Write
			if(j != m)
				*((ptr_out + i*n) + j) = *((ptr_a + i*n) + j);
		}
	}

	return out;
}
