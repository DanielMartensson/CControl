/*
 * norm.c
 *
 *  Created on: 13 jan. 2019
 *      Author: 
 */

#include "declareFunctions.h"

/*===========================================================================
 * norm
 * Get size norm value of a vector
 * Input: Vector (1 column matrix in other words)
 * Return: float
 * Works: OK
 *=========================================================================*/
float norm(matrix* a) {
	/*
	 * TODO: Only the euclidean norm here, please insert more norms if you need
	 */
	int n = a->row;
	float* ptr = a->data;

	float sum = 0; // Initial
	for (int i = 0; i < n; i++)
		sum += (*(ptr + i)) * (*(ptr + i));
	return sqrt(sum);
}
