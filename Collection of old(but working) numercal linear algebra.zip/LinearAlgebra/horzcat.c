/*
 * horzcat.c
 *
 *  Created on: 13 jan. 2019
 *      Author:
 */

#include "declareFunctions.h"

/*===========================================================================
 * horzcat
 * Concate a matrix a with matrix b on the horizontal
 * Input: Matrix, Matrix
 * Return: Matrix
 * Works: OK
 *=========================================================================*/
matrix* horzcat(matrix* a, matrix* b) {

	// Get the dimensions
	int n_a = a->row;
	int m_a = a->column;
	int m_b = b->column;

	// Get the data
	float* ptr_a = a->data;
	float* ptr_b = b->data;

	// Create the output - The extended matrix
	matrix* out = initMatrix(n_a, m_a + m_b);
	float* ptr = out->data;

	for (int i = 0; i < n_a; i++) {

		// We are at row i and we add the cells after the columns j
		for (int j = 0; j < m_a; j++) {
			*(ptr++) = *((ptr_a + i * m_a) + j);
		}

		// We change the matrix now - We use b matrix now
		for (int j = 0; j < m_b; j++) {
			*(ptr++) = *((ptr_b + i * m_b) + j);
		}
	}

	return out;
}
