/*
 * chol.c
 *
 *  Created on: 15 jan. 2019
 *      Author: 
 */

#include "declareFunctions.h"

/*===========================================================================
 * chol
 * Get the lower Cholesky factorization matrix from a matrix.
 * Input: Matrix
 * Return: Matrix
 * Works: OK
 *=========================================================================*/
matrix* chol(matrix* a) {
	int n = a->row;
	int m = a->column;
	float* ptr_a = a->data;
	matrix* L = zeros(n, m);
	float* ptr_L = L->data;

	for (int i = 0; i < n; i++)
		for (int j = 0; j < (i + 1); j++) {
			double s = 0;
			for (int k = 0; k < j; k++)
				s += *((ptr_L + i*n) + k) * (*((ptr_L + j*n) + k));

			// We cannot divide with zero
			if(*((ptr_L + j*n) + j) == 0){
				*((ptr_L + j*n) + j) = pow(2.2204, -16); // Same as eps command in MATLAB
			}
			*((ptr_L + i*n) + j) = (i == j) ? sqrt(*((ptr_a + i*n) + i) - s) : (1.0 / *((ptr_L + j*n) + j) * (*((ptr_a + i*n) + j) - s));
		}

	return L;
}

