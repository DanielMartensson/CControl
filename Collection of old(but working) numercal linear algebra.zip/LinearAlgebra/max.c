/*
 * max.c
 *
 *  Created on: 20 jan. 2019
 *      Author:
 */


#include "declareFunctions.h"

/*===========================================================================
 * max
 * Find max value and index
 * Input: Matrix (vector), pointer float, pointer int
 * Return: void
 * Works: OK
 *=========================================================================*/
void max(matrix* a, float* val, int* index) {
	int n = a->row;
	float* ptr = a->data;

	float past_val = 0;

	for(int i = 0; i < n; i++){
		if(*(ptr+i) > past_val){
			past_val = *(ptr+i); // Update
			*val = *(ptr+i);
			*index = i; // Remember the index position
		}
	}
}
