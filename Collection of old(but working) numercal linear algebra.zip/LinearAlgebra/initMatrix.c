/*
 * initMatrix.c
 *
 *  Created on: 13 jan. 2019
 *      Author: 
 */

#include "declareFunctions.h"

/*===========================================================================
 * initMatrix
 * Init a matrix with a column and row parameters.
 * Input: int row, int column
 * Return: Empty matrix
 * Works: OK
 * Notice that this function can use when you build on this library
 *=========================================================================*/
matrix* initMatrix(int row, int column) {
	matrix* out = (matrix*) malloc(sizeof(matrix));

	out->column = column;
	out->row = row;
	out->data = (float*) malloc(sizeof(float) * column * row);

	memset(out->data, 0.0, column * row * sizeof(float));

	return out;
}

