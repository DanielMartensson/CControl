/*
 * svd.c
 *
 *  Created on: 15 jan. 2019
 *      Author: 
 */

#include "declareFunctions.h"

/*===========================================================================
 * svd
 * Find the SVD of square matrix 'a' by using QR-method
 * Input: matrix* a, matrix* u, matrix* s, matrix* v
 * Return: void
 * Works: OK
 *=========================================================================*/
void svd(matrix* a, matrix* u, matrix* s, matrix* v){
	// Find data of matrix 'a'
	int n = a->row;
	int m = a->column;
	matrix* t; // Temporary matrix

	/*
	 * Initial declaration of values
	 */
	// Copy eye matrix to u
	t = eye(n, n);
	copyval(t, u);
	freeMatrix(t);

	// Copy transpose of 'a' to s
	t = tran(a);
	copyval(t, s);
	freeMatrix(t);

	// Copy eye matrix to v
	t = eye(m, m);
	copyval(t, v);
	freeMatrix(t);

	// Init q and r matrix for QR-facorization
	matrix* q = initMatrix(n,m);
	matrix* r = initMatrix(n,m);

	// Do while loop where we compute u,s,v
	for(int i = 0; i < 50; i++){
		// Solve QR from transpose of s
		t = tran(s);
		qr(t, q, r);
		freeMatrix(t);

		// Copy values from r to s
		copyval(r, s); // We do not need to delete r matrix yet

		// Copy u = u*q
		t = mul(u, q, false); // Not element wise
		copyval(t, u);
		freeMatrix(t);

		// Solve QR from transpose of s
		t = tran(s);
		qr(t, q, r);
		freeMatrix(t);

		// Copy values from r to s
		copyval(r, s); // We do not need to delete r matrix yet

		// Copy v = v*q
		t = mul(v, q, false);
		copyval(t, v);
		freeMatrix(t);

	}

	// Now we can delete r and q
	freeMatrix(q);
	freeMatrix(r);

	// Fix the s and v matrix, turn all the non-diagonal to zeros
	float* ptr_s = s->data;
	float* ptr_v = v->data;
	int n_s = s->row;
	int m_s = s->column;
	for(int i = 0; i < n_s; i++){
		for(int j = 0; j < m_s; j++){
			if(j != i){
				*((ptr_s + i*n) + j) = 0; // Non-diagonal need to be zeros
			}else{
				*((ptr_s + i*n) + j) = -*((ptr_s + i*n) + j); // They are negative, turn them positive
			}
			*((ptr_v + i*n) + j) = - *((ptr_v + i*n) + j); // Important to shift the v-values
		}
	}
}

