/*
 * repmat.c
 *
 *  Created on: 20 jan. 2019
 *      Author:
 */

#include "declareFunctions.h"

/*===========================================================================
 * repmat
 * Repeat matrix in different directions
 * Input: matrix, repeat horizontal, repeat vertical
 * Return: matrix
 * Works: OK
 *=========================================================================*/
matrix* repmat(matrix* a, int i, int j) {

	matrix* horz = initMatrix(a->row, a->column);
	matrix* vertz;
	matrix* mat;

	// copy - Initial start
	copyval(a, horz);

	// Copy horizontal
	for (int k = 0; k < i; k++) {
		mat = horzcat(horz, a);
		freeMatrix(horz);
		horz = scale(mat, 1); // Copy by using scale, copyval won't work
		freeMatrix(mat);
	}

	// Copy vertical
	if (i == 0) {
		return horz; // Return only the horizontal matrix because we don't compute vertical here
	} else {
		vertz = scale(horz, 1); // just initial copy
		for (int k = 0; k < j; k++) {
			mat = vertcat(vertz, horz);
			freeMatrix(vertz);
			vertz = scale(mat, 1); // Copy
			freeMatrix(mat);

		}
		freeMatrix(horz);
		return vertz;
	}

	return vertz;
}
