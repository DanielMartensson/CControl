/*
 * tran.c
 *
 *  Created on: 13 jan. 2019
 *      Author: 
 */

#include "declareFunctions.h"

/*===========================================================================
 * tran
 * Create a transpose matrix of a matrix
 * Input: Matrix
 * Return Transpose matrix
 * Works: OK
 *=========================================================================*/
matrix* tran(matrix* a) {
	matrix* out = initMatrix(a->column, a->row); // Notice that it's column first as argument
	float* ptrOut;
	float* ptrM = a->data;

	for (int i = 0; i < a->row; i++) {
		ptrOut = &out->data[i];
		for (int j = 0; j < a->column; j++) {
			*ptrOut = *ptrM;
			ptrM++;
			ptrOut += out->column;
		}
	}

	return out;
}
