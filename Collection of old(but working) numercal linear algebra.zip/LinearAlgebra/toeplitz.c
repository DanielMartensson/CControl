/*
 * toeplitz.c
 *
 *  Created on: 20 jan. 2019
 *      Author: 
 */

#include "declareFunctions.h"

/*===========================================================================
 * toeplitz
 * Create a toeplitz matrix of a 1D vector
 * Input: 1D float array, int step
 * Return: Matrix
 * Works: OK
 *=========================================================================*/
matrix* toeplitz(float* arr, int length) {

	matrix* out = initMatrix(length, length);
	float* ptr = out->data;

	for (int i = 0; i < length; i++) {
		for (int j = 0; j < length; j++) {
			if(i-j < 0)
				*((ptr + i * length) + j) = arr[j-i];
			else
				*((ptr + i * length) + j) = arr[i-j];
		}
	}


	return out;
}

