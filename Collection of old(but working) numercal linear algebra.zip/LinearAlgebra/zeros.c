/*
 * zeros.c
 *
 *  Created on: 13 jan. 2019
 *      Author:
 */

#include "declareFunctions.h"

/*===========================================================================
 * zeros
 * Returns an zeros matrix of size n by m
 * Input: int row, int column
 * Return: Matrix
 * Works: OK
 *=========================================================================*/
matrix* zeros(int n, int m) {

	matrix* out = initMatrix(n, m); // Already zero matrix due to memset
	return out;
}
