/*
 * printMatrix.c
 *
 *  Created on: 13 jan. 2019
 *      Author: 
 */

#include "declareFunctions.h"

/*===========================================================================
 * printMatrix
 * Prints a matrix
 * Input: Matrix
 * Return: void
 * Works: OK
 *=========================================================================*/
void printMatrix(matrix* a) {
	float* ptr = a->data;
	for (int i = 0; i < a->row; i++) {
		for (int j = 0; j < a->column; j++) {
			printf(" %9.6f", *(ptr++));
		}
		printf("\n");
	}
	printf("\n"); // Default new row
}
