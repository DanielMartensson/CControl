/*
 * tril.c
 *
 *  Created on: 15 jan. 2019
 *      Author:
 */

#include "declareFunctions.h"

/*===========================================================================
 * triu
 * Find the lower triangular matrix of matrix 'a'
 * Input: matrix* a, int shift
 * Return: Matrix
 * Works: OK
 *=========================================================================*/
matrix* tril(matrix* a, int shift){

	// Get info about matrix a
	int n = a->row;
	int m = a->column;
	float* ptr_a = a->data;

	matrix* out = initMatrix(n, m);
	float* ptr_out = out->data;

	// Create a triangular matrix
	for(int i = 0; i < n; i++){
		for(int j = 0; j < m; j++){

			// This will create a lower triangular matrix. Shift make sure that we can step shift steps to the right
			if(j <= i + shift){
				*((ptr_out + i*n) + j) = *((ptr_a + i*n) + j);
			}
		}
	}

	return out;
}

