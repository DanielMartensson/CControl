/*
 * mul.c
 *
 *  Created on: 13 jan. 2019
 *      Author: 
 */

#include "declareFunctions.h"

/*===========================================================================
 * mul
 * Multiply a matrix with another matrix. If elementWise is true, then you do element wize multiplication
 * Input: Matrix, Matrix, boolean (true/false)
 * Return: Matrix
 * Works: OK
 *=========================================================================*/
matrix* mul(matrix* a, matrix* b, bool elementWise) {
	// Get the dimensions - they both are the same
	int row_a = a->row;
	int column_a = a->column;
	//int row_b = b->row;
	int column_b = b->column;

	// Data
	float* data_a = a->data;
	float* data_b = b->data;

	if (elementWise == true) {
		matrix* out = initMatrix(row_a, column_a); // Same dimensions for a and b matrix
		float* ptr = out->data;
		// Dot multiply all values
		if (column_b > 1) { // If matrix b is a matrix
			for (int i = 0; i < row_a; i++) {
				for (int j = 0; j < column_a; j++) {
					// Do element wise mutiplication. In MATLAB it is A.*A
					*(ptr++) = *(data_a++) * *(data_b++);
				}
			}
		} else {
			// If matrix b is a vector
			for (int i = 0; i < row_a; i++) {
				for (int j = 0; j < column_a; j++) {
					// Do element wise mutiplication. In MATLAB it is A.*b
					*(ptr++) = *(data_a++) * *(data_b + i);
				}
			}
		}

		return out;
	} else {
		// Do regular mutiplication. In MATLAB it is A*A
		matrix* out = initMatrix(row_a, column_b);
		float* ptr = out->data;

		// Let's take our a matrix
		for (int i = 0; i < a->row; i++) {

			// Then we go through every column of b
			for (int j = 0; j < b->column; j++) {
				data_a = &a->data[i * a->column];
				data_b = &b->data[j];

				*ptr = 0; // Reset
				// And we multiply rows from a with columns of b
				for (int k = 0; k < a->column; k++) {
					*ptr += *data_a * *data_b;
					data_a++;
					data_b += b->column;
				}
				ptr++;
			}
		}

		return out;
	}

}
