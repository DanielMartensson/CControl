/*
 * mat2vec.c
 *
 *  Created on: 15 jan. 2019
 *      Author:
 */

#include "declareFunctions.h"

/*===========================================================================
 * vec
 * Create a vector from a matrix
 * Input: matrix* a
 * Return: Matrix (one long column matrix)
 * Works: OK
 *=========================================================================*/
matrix* vec(matrix* a){
	// Get data of 'a'
	int n = a->row;
	int m = a->column;
	float* ptr_a = a->data;

	// Create looooooooong vector
	matrix* out = initMatrix(n*m, 1);
	float* ptr_out = out->data;

	// This is the same as the GNU octave vec(a) or MATLAB command a(:)
	for(int i = 0; i < n; i++){
		for(int j = 0; j < m; j++){
			*(ptr_out++) = *((ptr_a + j*n) + i);
		}
	}

	return out;
}
