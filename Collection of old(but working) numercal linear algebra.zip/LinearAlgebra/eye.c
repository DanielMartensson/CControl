/*
 * eye.c
 *
 *  Created on: 13 jan. 2019
 *      Author:
 */

#include "declareFunctions.h"

/*===========================================================================
 * eye
 * Returns an identity matrix of size n by n, where n is the input
 * Input: int Row dimension.
 * Return: matrix
 * Works: OK
 *=========================================================================*/
matrix* eye(int n, int m) {

	matrix* out = initMatrix(n, m);

	float* ptr = out->data;
	for (int i = 0; i < n; i++) {
		*ptr = 1.0;
		ptr += n + 1;
	}

	return out;
}
