/*
 * pinv.c
 *
 *  Created on: 20 jan. 2019
 *      Author: 
 */

#include "declareFunctions.h"

/*===========================================================================
 * pinv
 * Find the pseudo inverse of a
 * Input: matrix* a
 * Return: matrix
 * Works: OK
 *=========================================================================*/
matrix* pinv(matrix* a){
	int n = a->row;
	int m = a->column;

	// Create U,S,V - matrix 'a' need to be square for the moment, so n == m. You want to code so n != m ?
	matrix* u = initMatrix(n, n);
	matrix* s = initMatrix(n, m);
	matrix* v = initMatrix(m, m);

	// Solve SVD
	svd(a, u, s, v);

	// Solve out = v*inv(s)*tran(u)
	matrix* mat0 = inv(s);
	matrix* mat1 = tran(u);
	matrix* mat2 = mul(mat0, mat1, false);
	matrix* out = mul(v, mat2, false);

	// delete
	freeMatrix(u);
	freeMatrix(s);
	freeMatrix(v);
	freeMatrix(mat0);
	freeMatrix(mat1);
	freeMatrix(mat2);

	return out;


}


