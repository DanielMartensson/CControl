/*
 * hankel.c
 *
 *  Created on: 20 jan. 2019
 *      Author: 
 */

#include "declareFunctions.h"

/*===========================================================================
 * hankel
 * Create a hankel matrix of a 1D vector
 * Input: 1D float array, int step
 * Return Matrix
 * Works: OK
 *=========================================================================*/
matrix* hankel(float* arr, int length, int step) {

	matrix* out = initMatrix(length, length);
	float* ptr = out->data;

	for(int i = 0; i < length; i++){
		for(int j = 0; j < length; j++){
			if(j+i+step >= length){
				*((ptr + i*length) + j) = 0;
			}else{
				*((ptr + i*length) + j) = arr[j+i+step];
			}

		}
	}

	return out;

}


