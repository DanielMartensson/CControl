/*
 * sqrtm.c
 *
 *  Created on: 20 jan. 2019
 *      Author:
 */

#include "declareFunctions.h"

/*===========================================================================
 * sqrtm
 * Take square root of every element in the matrix
 * Input: Matrix
 * Return: Matrix
 * Works: OK
 *=========================================================================*/
matrix* sqrtm(matrix* a){

	int n = a->row;
	int m = a->column;
	float* ptr_a = a->data;

	matrix* out = initMatrix(n,m);
	float* ptr_out = out->data;

	for(int i = 0; i < n; i++){
		for(int j = 0; j < m; j++){
			*(ptr_out++) = sqrt(*(ptr_a++));
		}
	}

	return out;
}


