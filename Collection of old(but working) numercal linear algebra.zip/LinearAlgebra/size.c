/*
 * size.c
 *
 *  Created on: 13 jan. 2019
 *      Author: 
 */

#include "declareFunctions.h"

/*===========================================================================
 * size
 * Get size row x column of matrix
 * Input: Matrix, int pointer for row, int pointer for column
 * Return: Void
 * Works: OK
 *=========================================================================*/
void size(matrix* m, int* row, int* column) {
	*row = m->row;
	*column = m->column;
}
