/*
 * vertcat.c
 *
 *  Created on: 13 jan. 2019
 *      Author:
 */

#include "declareFunctions.h"

/*===========================================================================
 * vertcat
 * Concate a matrix a with matrix b on the vertical
 * Input: Matrix, Matrix
 * Return: Matrix
 * Works: OK
 *=========================================================================*/
matrix* vertcat(matrix* a, matrix* b) {

	// Get the dimensions
	int n_a = a->row;
	int m_a = a->column;
	int n_b = b->row;

	// Get the data
	float* ptr_a = a->data;
	float* ptr_b = b->data;

	// Create the output - The extended matrix
	matrix* out = initMatrix(n_a + n_b, m_a);
	float* ptr = out->data;

	// We include the first matrix a
	for (int i = 0; i < n_a; i++) {
		for (int j = 0; j < m_a; j++) {
			*(ptr++) = *((ptr_a + i * m_a) + j);
		}
	}

	// We change the matrix now - We use b matrix now
	for (int i = 0; i < n_b; i++) {
		for (int j = 0; j < m_a; j++) {
			*(ptr++) = *((ptr_b + i * m_a) + j);
		}
	}

	return out;
}
