/*
 * cofact.c
 *
 *  Created on: 13 jan. 2019
 *      Author:
 */

#include "declareFunctions.h"

/*===========================================================================
 * cofact
 * Find the cofactor matrix of a matrix
 * Input: Matrix
 * Return: cofactor matrix
 * Works: OK
 *=========================================================================*/
matrix* cofact(matrix* a) {

	int n = a->row;
	float* ptr_a = a->data;

	// Create our matrix - cofactor
	matrix* out = initMatrix(n, n);
	float* ptr_out = out->data;

	// Create the minor matrix - Allways one size smaller
	matrix* minor = initMatrix(n-1, n-1);
	float* ptr_minor = minor->data;

	// Starting position
	int row = 0;
	int column = 0;
	int minorCellposition = 0;

	// What we do is to create sub matrices for every cell. 3x3 means 9 sub matrices
	for (int k = 0; k < n * n; k++) {

		// Loop rows
		for (int i = 0; i < n; i++) {
			// Loop columns
			for (int j = 0; j < n; j++) {
				// Check if we are not on the "forbidden" row and column
				if (i != row && j != column) {
					// Insert
					*(ptr_minor + minorCellposition) = *((ptr_a + i * n) + j);
					minorCellposition++; // Next cell
				}
			}
		}

		// Insert in our output
		*(ptr_out++) = pow(-1, row+column)* det(minor); //pow is needed because turning minor matrix to cofactor matrix

		// Update - Remember n-1 is due to indexing from zero
		if(column < n-1){
			column++; // Next column
		}else{
			column = 0;
			row++; // Next row
		}

		// Reset the minor matrix and jump back to cell position 0
		resetMatrix(minor);
		minorCellposition = 0;

	}

	// Delete the minor matrix - we don't need it
	freeMatrix(minor);

	return out;
}
