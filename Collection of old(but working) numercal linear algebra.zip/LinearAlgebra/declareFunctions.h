/*
 * declareFunctions.h
 *
 *  Created on: 13 jan. 2019
 *      Author: 
 */

#ifndef LINEARALGEBRA_DECLAREFUNCTIONS_H_
#define LINEARALGEBRA_DECLAREFUNCTIONS_H_


// Matrix structure
typedef struct _matrix {
    int row;
    int column;
    float* data;
} matrix;

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include<math.h>


/* Use these when you using the library */
matrix* initMatrix(int row, int column);
void freeMatrix(matrix* a);
void printMatrix(matrix* a);
matrix* cut(matrix* a, int start_n, int stop_n, int start_m, int stop_m);
matrix* horzcat(matrix* a, matrix* b);
matrix* vertcat(matrix* a, matrix* b);
float det(matrix* a);
matrix* cofact(matrix* a);
matrix* create(float* arr2D, int n, int m);
matrix* eye(int n, int m);
matrix* tran(matrix* a);
matrix* add(matrix* a, matrix* b);
matrix* sub(matrix* a, matrix* b);
void size(matrix* m, int* row, int* column);
matrix* scale(matrix* a, float value);
matrix* mul(matrix* a, matrix* b, bool elementWise);
matrix* ones(int n, int m);
matrix* zeros(int n, int m);
matrix* diag(float* arr, int length);
matrix* inv(matrix* a);
matrix* linsolve(matrix*a, matrix* b);
float norm(matrix* a);
void qr(matrix* a, matrix* q, matrix* r);
float dot(matrix* a, matrix* b);
void svd(matrix* a, matrix* u, matrix* s, matrix* v);
void copyval(matrix*a, matrix* b);
matrix* triu(matrix* a, int shift);
matrix* tril(matrix* a, int shift);
matrix* vec(matrix* a);
matrix* diagm(matrix* a);
matrix* chol(matrix* a);
void lu(matrix* a, matrix* l, matrix* u);
matrix* repmat(matrix* a, int i, int j);
void max(matrix* a, float* val, int* index);
void min(matrix* a, float* val, int* index);
matrix* summ(matrix* a);
matrix* absm(matrix* a);
matrix* sqrtm(matrix* a);
matrix* hankel(float* arr, int length, int step);
matrix* toeplitz(float* arr, int length);
matrix* pinv(matrix* a);
void resetMatrix(matrix* a);


#endif /* LINEARALGEBRA_DECLAREFUNCTIONS_H_ */
