/*
 * inv.c
 *
 *  Created on: 13 jan. 2019
 *      Author: 
 */

#include "declareFunctions.h"

/*===========================================================================
 * inv
 * Returns an inverse matrix of a matrix
 * Input: Matrix
 * Return: Inverse matrix
 * Works: OK
 *=========================================================================*/
matrix* inv(matrix* a) {

	/*
	 * This uses LU decomposation to find the inverse of matrix a
	 */

	int n = a->row;
	int m = a->column;
	matrix* I = eye(n, m);
	matrix* vectorI;
	matrix* x;
	matrix* out = initMatrix(m, m);
	float* ptr_out = out->data;

	for (int i = 0; i < n; i++) {
		// Cut out one column of I
		vectorI = cut(I, 0, n-1, i, i);
		x = linsolve(a, vectorI);
		float* ptr_x = x->data;
		// Delete matrix
		freeMatrix(vectorI);
		for (int j = 0; j < n; j++) {
			*((ptr_out + j * n) + i) = *(ptr_x + j);
		}
		freeMatrix(x);

	}
	freeMatrix(I);

	return out;
}
