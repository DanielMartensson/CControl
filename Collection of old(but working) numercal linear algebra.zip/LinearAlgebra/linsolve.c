/*
 * linsolve.c
 *
 *  Created on: 13 jan. 2019
 *      Author:
 */

#include "declareFunctions.h"

/*===========================================================================
 * linsolve
 * Solve the equation Ax=b if we know A and b
 * Input: Matrix, Matrix (which can be a vector)
 * Return: Matrix (vector)
 * Works: OK
 *=========================================================================*/
matrix* linsolve(matrix*a, matrix* b) {

	/*
	 * This uses LU-factorization to solve Ax = b equation
	 */

	// Get data for matrix a
	int n = a->row;
	int m_a = a->column;

	// Get data for matrix b
	int m_b = b->column;
	float* ptr_b = b->data;

	// Do LU-factorization
	matrix* l = initMatrix(n, m_a);
	matrix* u = initMatrix(n, m_a);
	lu(a, l, u);

	// Get pointers
	float* ptr_l = l->data;
	float* ptr_u = u->data;

	// Initial sum
	float sum = 0;

	matrix* y = initMatrix(n, m_b); // Vector
	matrix* x = initMatrix(n, m_b); // Vector
	float* ptr_y = y->data;
	float* ptr_x = x->data;

	// Solve Ly = b with gaussian elimination
	for (int i = 0; i < n; i++) {
		sum = 0;
		for (int j = 0; j < i; j++)
			sum += *((ptr_l + i * n) + j) * (*(ptr_y + j));
		*(ptr_y + i) = (*(ptr_b + i) - sum) / (*((ptr_l + i * n) + i));
	}

	// Solve Ux = y with gaussian elimination
	for (int i = n-1; i >= 0; i--) {
		sum = 0;
		for (int j = i; j < n; j++)
			sum += *((ptr_u + i * n) + j) * (*(ptr_x + j));
		*(ptr_x + i) = (*(ptr_y + i) - sum) / (*((ptr_u + i * n) + i));
	}

	// Remove following matrix
	freeMatrix(l);
	freeMatrix(u);
	freeMatrix(y);
	return x;

}
